#ifndef MUPDF_QT_H
#define MUPDF_QT_H

#include "mupdf-document.h"
#include "mupdf-page.h"
#include "mupdf-link.h"
#include "mupdf-outline.h"
#include "mupdf-textbox.h"

#endif // end MUPDF_QT_H
