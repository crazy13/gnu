#define ZLOG_GIT_SHA1 "acbd8c41"
#define ZLOG_GIT_DIRTY "8"
